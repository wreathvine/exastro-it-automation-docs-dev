// JavaScript Document

var myfunc = function (button) {
 alert('Hello!');
}