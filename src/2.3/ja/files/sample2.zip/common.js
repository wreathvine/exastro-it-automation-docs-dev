// JavaScript Document

window.addEventListener('DOMContentLoaded', () => {    
    if ( window.parent ) {
    
    const $content = $('#content');
    
    const ui = new CommonUi();
    
    const tabs = [
      { name: 'operation_list', title: 'オペレーション一覧', type: 'blank'},
      { name: 'movement_list', title: 'Movement一覧', type: 'blank'},
      { name: 'device_list', title: '機器一覧', type: 'blank'}
    ];
    
    $content.addClass('tabContent').html( ui.commonContainer('独自メニューサンプル', '独自メニューのサンプルです。各種一覧ページを表示しています。', ui.contentTab( tabs ), false ) );
    ui.contentTabEvent('#operation_list');
    
    for ( const tab of tabs ) {
      fn.fetch(`/menu/${tab.name}/info/`).then(function( info ){
        const params = fn.getCommonParams();
        params.menuNameRest = tab.name;

        const table = new DataTable('TABLE_' + tab.name , 'view', info, params );
        $('#' + tab.name ).find('.sectionBody').html( table.setup() );
      });
    }
    
    }   
});